package com.cts.connect_project.dao;

import com.cts.connect_project.bean.Help;

public interface HelpDao {
 public String insertHelp(Help help);
}
