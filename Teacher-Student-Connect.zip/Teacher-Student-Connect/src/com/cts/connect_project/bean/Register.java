package com.cts.connect_project.bean;

import java.io.InputStream;

public class Register {

    private String fname;
    private String lname;
    private String age;
    private String gender;
    private String cno;
    private String cat;
    private String userid;
    private String password;
    private String specialization;
    private String  ac_b;
    private InputStream pic;
	
    
    public Register(String fname, String userid) {
		super();
		this.fname = fname;
		this.userid = userid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	public String getCat() {
		return cat;
	}
	public void setCat(String cat) {
		this.cat = cat;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public Register() {
		super();
	}
	
	
	
	
	
	public Register(String fname, String lname, String age, String gender, String cno, String cat, String userid,
			String password, String specialization, String ac_b, InputStream pic) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.gender = gender;
		this.cno = cno;
		this.cat = cat;
		this.userid = userid;
		this.password = password;
		this.specialization = specialization;
		this.ac_b = ac_b;
		this.pic = pic;
	}
	public InputStream getPic() {
		return pic;
	}
	public void setPic(InputStream pic) {
		this.pic = pic;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getAc_b() {
		return ac_b;
	}
	public void setAc_b(String ac_b) {
		this.ac_b = ac_b;
	}
	
    

	
}
